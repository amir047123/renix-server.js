const express = require("express");
const cors = require("cors");

const app = express();

// Configure CORS
const corsOptions = {
  origin: [
    "https://www.renixlaboratories.com.bd",
    "https://renixlaboratories.com.bd",
    "http://localhost:3000",
  ], // Allowed domains
  methods: "GET,HEAD,PUT,PATCH,POST,DELETE", // Allowed methods
  credentials: true, // Enable credentials if needed
};

app.use(cors(corsOptions));
app.use(express.json());

// Import routes
const adminEdit = require("./routes/adminEdit.route");
const doctors = require("./routes/doctors.route");
const imageUploadRoutes = require("./routes/imageUpload.route");
const medicineRoute = require("./routes/medicine.route");
const categoryRoute = require("./routes/category.route");
const blogsCategoryRoute = require("./routes/blogsCategoryRoute");
const blogsRoute = require("./routes/blogs.route");
const orderRoute = require("./routes/order.route");
const userRoutes = require("./routes/user.route");
const appointmentRoute = require("./routes/appointment.route");
const contactRenix = require("./routes/contactRenix.route");
const collectEmail = require("./routes/collectEmail.route");
const shippingRoutes = require("./routes/shipping.route");
const newsAndMediaRouter = require("./routes/newsAndMedia.route");
const seoRoutes = require("./routes/seo.route");
const slideRouter = require("./routes/slide.route");

// Register routes
app.use("/api/v1/user", userRoutes);
app.use("/api/v1/upload", imageUploadRoutes);
app.use("/api/v1/adminEdit", adminEdit);
app.use("/api/v1/doctors", doctors);
app.use("/api/v1/medicine", medicineRoute);
app.use("/api/v1/category", categoryRoute);
app.use("/api/v1/blogsCategory", blogsCategoryRoute);
app.use("/api/v1/blogs", blogsRoute);
app.use("/api/v1/order", orderRoute);
app.use("/api/v1/appointment", appointmentRoute);
app.use("/api/v1/contactRenix", contactRenix);
app.use("/api/v1/collectEmail", collectEmail);
app.use("/api/v1/shipping", shippingRoutes);
app.use("/api/v1/newsAndMedia", newsAndMediaRouter);
app.use("/api/v1/slide", slideRouter);
app.use("/api/v1/seo", seoRoutes);

// Serve images
app.get("/images/:filename", (req, res) => {
  const filename = req.params.filename;
  res.sendFile(__dirname + "/image/" + filename);
});

// Default route
app.get("/", (req, res) => {
  res.send(
    `<h1 style="color:#00ff00;font-size:62px; text-align:center;margin-top:200px">"Database Running with Faysal & Ifty"</h1>`
  );
});

module.exports = app;
